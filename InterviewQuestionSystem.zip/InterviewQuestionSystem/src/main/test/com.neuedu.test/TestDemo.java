package com.neuedu.test;

import com.github.pagehelper.PageInfo;
import com.neuedu.dao.UserDao;
import com.neuedu.entity.User;
import com.neuedu.service.SubServiceImpl;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class TestDemo {
    SqlSessionFactory sqlSessionFactory = null;

    @Before
    public void before(){
        String resource = "SqlMapConifg.xml";
        InputStream inputStream = null;
        try {
            inputStream = Resources.getResourceAsStream(resource);
        } catch (IOException e) {
            e.printStackTrace();
        }
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

    }
    @Test
    public void Test(){
        SubServiceImpl subService = new SubServiceImpl();
        User user = new User();
        user.setId(267);
        PageInfo pageInfo = subService.querySubjectByPage(user, 1, 3);
        System.out.println(pageInfo);

//        //mapper动态代理方式
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        UserDao mapper = sqlSession.getMapper(UserDao.class);
//        List<User> allUser = mapper.getAllUser();
//        System.out.println(allUser);

        //模糊查询测试
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        List<User> users = sqlSession.selectList("com.neuedu.mapper.selectUserByName","%张%");
//        System.out.println(users);

        //添加测试
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        User user = new User(null, "刘四", "123456", "14522580@163.com", "13513320220", "你的家乡在哪", "东北", 1, null, null);
//        int insert = sqlSession.insert("com.neuedu.mapper.addOneUser", user);
//        System.out.println(insert);
//        sqlSession.commit();
//        System.out.println(user);

        //修改测试
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        User user = new User(8, "司徒", "123456", "14522580@163.com", "13513320220", "你的家乡在哪", "河北", 1, null, null);
//        int update = sqlSession.update("com.neuedu.mapper.updateUserById", user);
//        System.out.println(update);
//        sqlSession.commit();

        //删除测试
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        int delete = sqlSession.delete("com.neuedu.mapper.deleteUserById", 7);
//        System.out.println(delete);
//        sqlSession.commit();





    }

    @After
    public void after(){

    }
}
