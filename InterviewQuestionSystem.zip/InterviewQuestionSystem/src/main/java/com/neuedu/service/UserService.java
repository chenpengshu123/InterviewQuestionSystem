package com.neuedu.service;

import com.neuedu.entity.User;

public interface UserService {

    //判断用户是否存在
    User login(User user);
    boolean register(User user);
    User queryUserIsExistsByPhone(String phone);
}
