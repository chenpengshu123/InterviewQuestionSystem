package com.neuedu.service;

import com.github.pagehelper.PageInfo;
import com.neuedu.entity.Subject;
import com.neuedu.entity.User;

public interface SubService {

    //添加面试题
    Integer addSubject(Subject subject);

    //查询面试题
    PageInfo querySubjectByPage(User user,Integer pageNum,Integer pageSize);

    // 根据id查询面试题
    Subject querySubById(Integer id);

    // 根据id修改面试题
    boolean updateSubject(Subject subject);
}
