package com.neuedu.service;

import com.neuedu.dao.UserDao;
import com.neuedu.entity.User;
import com.neuedu.utils.SqlSessionFacUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.omg.CosNaming.BindingIterator;

public class UserServiceImpl implements UserService {
    private SqlSessionFactory sqlSessionFactory= SqlSessionFacUtil.createSqlSessionFactory();
    @Override
    public User login(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        User user1 = mapper.queryUserIsExists(user);
        sqlSession.close();
        return user1;
    }

    @Override
    public boolean register(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        boolean b = mapper.addOneUser(user);
        sqlSession.commit();
        sqlSession.close();
        return b;
    }

    @Override
    public User queryUserIsExistsByPhone(String phone) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        User user = mapper.queryUserIsExistsByPhone(phone);
        sqlSession.commit();
        sqlSession.close();
        return user;
    }
}
