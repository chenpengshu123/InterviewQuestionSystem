package com.neuedu.controller;

import com.alibaba.fastjson.JSONObject;
import com.neuedu.common.HigherResponse;
import com.neuedu.entity.Subject;
import com.neuedu.service.SubService;
import com.neuedu.service.SubServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UpdateSubServlet",urlPatterns = "/user/update.do")
public class UpdateSubServlet extends HttpServlet {
    private SubService subService;

    @Override
    public void init() throws ServletException {
        subService = new SubServiceImpl();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sid = req.getParameter("sid");
        int i = Integer.parseInt(sid);
        Subject subject = subService.querySubById(i);
        if(null == subject){
            HigherResponse<Object> higherResponse = new HigherResponse<>(0, "查询不到该条数据");
            String s = JSONObject.toJSONString(higherResponse);
            resp.getWriter().write(s);
            return;
        }else{
            HigherResponse<Subject> higherResponse = new HigherResponse<>(1, subject);
            String s = JSONObject.toJSONString(higherResponse);
            resp.getWriter().write(s);
            return;
        }
    }
}
