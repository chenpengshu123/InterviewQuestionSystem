package com.neuedu.controller;

import com.alibaba.fastjson.JSONObject;
import com.neuedu.common.HigherResponse;
import com.neuedu.entity.User;
import com.neuedu.service.UserService;
import com.neuedu.service.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "RegisterServlet",urlPatterns = "/user/register.do")
public class RegisterServlet extends HttpServlet {

    private UserService userService;

    @Override
    public void init() throws ServletException {
        userService = new UserServiceImpl();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String psw = req.getParameter("psw");
        String nick = req.getParameter("nick");
        String real = req.getParameter("real");
        String r = req.getParameter("role");
        int role = Integer.parseInt(r);
        if ("".equals(name) || name.length()==0){
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(0, "用户名不能为空！！");
            String s = JSONObject.toJSONString(objectHigherResponse);
            resp.getWriter().write(s);
            return;
        }
        if ("".equals(psw) || psw.length()==0){
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(0, "密码不能为空！！");
            String s = JSONObject.toJSONString(objectHigherResponse);
            resp.getWriter().write(s);
            return;
        }
        if ("".equals(nick) || nick.length()==0){
            nick = null;
        }
        if ("".equals(real) || real.length()==0){
            real = null;
        }


        User user = new User(null,name,psw,nick,real,role,null,null,null);
        boolean register = userService.register(user);
        if (register){
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(1, "注册成功，请登录~");
            String s = JSONObject.toJSONString(objectHigherResponse);
            resp.getWriter().write(s);
        }else {
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(0, "注册失败，请重新注册~");
            String s = JSONObject.toJSONString(objectHigherResponse);
            resp.getWriter().write(s);
        }


    }
}
