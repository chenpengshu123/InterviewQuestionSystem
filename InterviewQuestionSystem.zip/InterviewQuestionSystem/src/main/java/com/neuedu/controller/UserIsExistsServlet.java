package com.neuedu.controller;

import com.alibaba.fastjson.JSONObject;
import com.neuedu.common.HigherResponse;
import com.neuedu.entity.User;
import com.neuedu.service.UserService;
import com.neuedu.service.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UserIsExistsServlet",urlPatterns = "/user/userIsExists.do")
public class UserIsExistsServlet extends HttpServlet {

    private UserService userService;

    @Override
    public void init() throws ServletException {
        userService = new UserServiceImpl();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String phone = req.getParameter("phone");
        User user = userService.queryUserIsExistsByPhone(phone);
        if (null != user){
            HigherResponse<User> userHigherResponse = new HigherResponse<>(1, user);
            String s = JSONObject.toJSONString(userHigherResponse);
            resp.getWriter().write(s);
            return;
        }else {
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(0, "没有该用户");
            String s = JSONObject.toJSONString(objectHigherResponse);
            resp.getWriter().write(s);
            return;
        }
    }
}
