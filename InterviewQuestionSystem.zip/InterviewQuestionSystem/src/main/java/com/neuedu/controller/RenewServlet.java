package com.neuedu.controller;

import com.alibaba.fastjson.JSONObject;
import com.neuedu.common.HigherResponse;
import com.neuedu.entity.Subject;
import com.neuedu.service.SubService;
import com.neuedu.service.SubServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "RenewServlet",urlPatterns = "/user/re.do")
public class RenewServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        subService = new SubServiceImpl();
    }

    private SubService subService;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sid = req.getParameter("sid");
        String url = req.getParameter("url");
        String company = req.getParameter("company");
        String companyAddress = req.getParameter("companyAddress");
        String[] subTypes = req.getParameterValues("subType");
        // java html mysql
        // java,html,mysql
        String jobName = req.getParameter("jobName");
        String level = req.getParameter("level");

        int changeSid = Integer.parseInt(sid);
        String str = "";
        for(int i=0;i<subTypes.length;i++){
            str += subTypes[i];
            if(i != subTypes.length-1){
                str += ",";
            }
        }
        int changeLevel = Integer.parseInt(level);
        Subject subject = new Subject(changeSid,url,company,companyAddress,str,jobName,null,(byte)changeLevel,null,null,null);
        boolean b = subService.updateSubject(subject);
        if(b){
            HigherResponse<Object> higherResponse = new HigherResponse<>(1, "修改成功");
            String s = JSONObject.toJSONString(higherResponse);
            resp.getWriter().write(s);
            return;
        }else{
            HigherResponse<Object> higherResponse = new HigherResponse<>(0, "修改失败");
            String s = JSONObject.toJSONString(higherResponse);
            resp.getWriter().write(s);
            return;
        }
    }
}
