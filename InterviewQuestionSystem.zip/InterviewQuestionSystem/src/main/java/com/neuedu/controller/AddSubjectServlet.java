package com.neuedu.controller;

import com.alibaba.fastjson.JSONObject;
import com.neuedu.common.HigherResponse;
import com.neuedu.entity.Subject;
import com.neuedu.entity.User;
import com.neuedu.service.SubService;
import com.neuedu.service.SubServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;

@WebServlet(name = "AddSubjectServlet",urlPatterns = "/user/addSub.do")
public class AddSubjectServlet extends HttpServlet {
    private SubService subService;

    @Override
    public void init() throws ServletException {
        subService = new SubServiceImpl();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getParameter("url");
        String company = req.getParameter("company");
        String companyAddress = req.getParameter("companyAddress");
        String[] subTypes = req.getParameterValues("subType");
        String jobName = req.getParameter("jobName");
        String level = req.getParameter("level");
        //从Session获取userId
        HttpSession session = req.getSession();
        User user =(User) session.getAttribute("userInfo");
        if(null == user){
            HigherResponse<Object> objectHigherResponse;
            objectHigherResponse = new HigherResponse<>(0, "登录过期，请重新登录");
            resp.getWriter().write(JSONObject.toJSONString(objectHigherResponse));
            return;
        }
        Integer id = user.getId();
        int changeLevel = Integer.parseInt(level);
        String str = "";
        for(int i=0;i<subTypes.length;i++){
            str += subTypes[i];
            if(i != subTypes.length-1){
                str += ",";
            }
        }
        System.out.println("subtype:"+str);
        Subject subject = new Subject(null, url, company, companyAddress, str, jobName, id, (byte) changeLevel, null, null, null);
        Integer integer = subService.addSubject(subject);
        if(integer>0){
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(1,"添加成功");
            resp.getWriter().write(JSONObject.toJSONString(objectHigherResponse));
            return;
        }else {
            HigherResponse<Object> objectHigherResponse = new HigherResponse<>(0,"添加失败");
            resp.getWriter().write(JSONObject.toJSONString(objectHigherResponse));
            return;
        }


    }
}
